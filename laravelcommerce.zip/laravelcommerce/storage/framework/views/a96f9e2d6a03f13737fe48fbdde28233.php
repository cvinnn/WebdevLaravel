<?php $__env->startSection('title', 'Pesan'); ?>
<?php $__env->startSection('body'); ?>
<div class="container-fluid bg-dark text-white py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 ">
            <div class="  text-white">
                <h1 class="display-1">Success!</h1>
                <p class="lead"><?php echo e($message); ?></p>
                <hr class="my-6">
                <p class="lead">
                    <a class="btn btn-light btn-lg bg-success text-white" href="<?php echo e($contactListRoute); ?>" role="button">See Contact List</a>
                    <a class="btn btn-light btn-lg " href="<?php echo e($formRoute); ?>" role="button">Back To Form</a>
                </p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelCommerce\resources\views/message.blade.php ENDPATH**/ ?>